<header class="site-header"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <div class="container-fluid">
      <a href="dashboard.php" class="site-logo">
         <img cla/ss="hidden-md-down" src="images/logo.svg" alt="" style="height:100px;">               
         <!--<img class="hidden-lg-down" src="images/logo.svg" alt=""  style="height:80px;">-->
      </a>
      <div class="site-header-content">
         <div class="site-header-content-in">
            <div class="site-header-shown">
                <!--<div class="dropdown user-menu">
               <a href="http://tisvdigital.com/trustees/" target="_blank"><button type="button" class="btn btn-inline btn-fcmb" > Go back to Main website </button>  </a>                          
               </div>
               <div class="dropdown user-menu">
               <a href="logout.php"><button type="button" class="btn btn-inline btn-fcmb" >  Logout  </button>            </a>                
               </div>-->
               <div class="dropdown user-menu">
	                        <button class="dropdown-toggle" id="dd-user-menu" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
	                            <img src="img/avatar-2-64.png" alt="">
	                        </button>
	                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dd-user-menu">
	                            <a class="dropdown-item" href="http://www.fcmbtrustees.com/" target="_blank" style="color:#5C0F8B;"><span class="font-icon glyphicon glyphicon-cog" style="color:#5C0F8B;"></span>Go back to Main website</a>
	                            <div class="dropdown-divider"></div>
	                            <a class="dropdown-item" style="color:#5C0F8B;" href="logout.php"><span class="font-icon glyphicon glyphicon-log-out" style="color:#5C0F8B;"></span>Logout</a>
	                        </div>
	                    </div>
            </div>
            <!--.site-header-shown-->               
         </div>
         <!--site-header-content-in-->          
      </div>
      <!--.site-header-content-->       
   </div>
   <!--.container-fluid-->  
</header>
<!--.site-header-->